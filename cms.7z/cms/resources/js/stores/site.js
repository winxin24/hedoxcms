import { defineStore } from 'pinia'

export const useSiteStore = defineStore('site', {
    state: () => ({
        currentSite: null,
        sharedData: {}
    }),
    actions: {
        async loadSite() {
            const { data } = await axios.get('/api/site')
            this.currentSite = data
        },
        async fetchSharedContent(type) {
            const { data } = await axios.get(`/shared-content/${type}`)
            this.sharedData[type] = data
        }
    },
    getters: {
        siteConfig: (state) => state.currentSite?.config || {}
    }
}) 