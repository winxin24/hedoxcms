<?php
class MobileThemeAdapter {
    public function render(string $view, array $data = []): string {
        $theme = request()->attributes->get('theme', 'desktop');
        $view = "{$theme}/{$view}";
        
        return $this->themeEngine->render($view, $data);
    }
} 