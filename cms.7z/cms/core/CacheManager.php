<?php
class CacheManager {
    private $redis;
    const DEFAULT_TTL = 3600;
    const LOCK_TIMEOUT = 5; // 秒

    public function __construct(Redis $redis) {
        $this->redis = $redis;
    }

    public function getWithLock(string $key, callable $callback, int $ttl = null) {
        $data = $this->redis->get($key);
        if ($data !== false) {
            return json_decode($data, true);
        }

        $lockKey = "lock:$key";
        if ($this->acquireLock($lockKey)) {
            try {
                $data = $callback();
                $this->redis->setex($key, $ttl ?? self::DEFAULT_TTL, json_encode($data));
                return $data;
            } finally {
                $this->releaseLock($lockKey);
            }
        }

        // 等待其他进程完成缓存重建
        usleep(100000); // 100ms
        return $this->getWithLock($key, $callback, $ttl);
    }

    private function acquireLock(string $key): bool {
        return $this->redis->set(
            $key,
            microtime(true),
            ['nx', 'ex' => self::LOCK_TIMEOUT]
        );
    }

    private function releaseLock(string $key): void {
        $this->redis->del($key);
    }
} 