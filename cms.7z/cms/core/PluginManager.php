class PluginManager {
    private $hooks = [];
    
    public function addFilter(string $hook, callable $callback, int $priority = 10) {
        $this->hooks[$hook][$priority][] = $callback;
    }
    
    public function applyFilters(string $hook, $value, ...$args) {
        if (isset($this->hooks[$hook])) {
            ksort($this->hooks[$hook]);
            foreach ($this->hooks[$hook] as $callbacks) {
                foreach ($callbacks as $callback) {
                    $value = $callback($value, ...$args);
                }
            }
        }
        return $value;
    }
    
    public function loadPlugins(string $dir) {
        // 自动加载插件目录中的模块
    }
} 