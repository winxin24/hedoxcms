<?php
class ThemeEngine {
    private $manifestCache = [];

    public function render(string $view, array $data = []) {
        extract($data);
        ob_start();
        include $this->locateTemplate($view);
        return $this->processOutput(ob_get_clean());
    }

    private function locateTemplate(string $view): string {
        $paths = [
            STYLESHEETPATH . "/{$view}.php",
            TEMPLATEPATH . "/{$view}.php"
        ];

        foreach ($paths as $path) {
            if (file_exists($path)) {
                return $path;
            }
        }

        throw new TemplateNotFoundException($view);
    }

    private function processOutput(string $content): string {
        // 自动添加版本号到静态资源
        return preg_replace_callback(
            '/(href|src)=["\']([^"\']+)["\']/',
            function ($matches) {
                return $matches[1] . '="' . $this->addAssetVersion($matches[2]) . '"';
            },
            $content
        );
    }

    private function addAssetVersion(string $url): string {
        $manifest = $this->getManifest();
        $path = parse_url($url, PHP_URL_PATH);
        return $url . (isset($manifest[$path]) ? '?v=' . $manifest[$path] : '');
    }
} 