<?php
class Scheduler {
    private $jobs = [];
    private $lock;

    public function __construct(Redis $redis) {
        $this->lock = $redis;
    }

    public function addJob(string $name, string $cron, callable $callback): void {
        $this->jobs[$name] = [
            'cron' => CronExpression::factory($cron),
            'callback' => $callback
        ];
    }

    public function run(): void {
        foreach ($this->jobs as $name => $job) {
            if ($job['cron']->isDue() && $this->acquireLock($name)) {
                try {
                    call_user_func($job['callback']);
                } finally {
                    $this->releaseLock($name);
                }
            }
        }
    }

    private function acquireLock(string $name): bool {
        $key = "scheduler:lock:{$name}";
        return $this->lock->set($key, time(), ['nx', 'ex' => 300]);
    }

    private function releaseLock(string $name): void {
        $this->lock->del("scheduler:lock:{$name}");
    }
} 