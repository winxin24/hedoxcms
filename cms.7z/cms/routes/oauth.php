<?php
$router->get('/auth/{provider}', function ($provider) use ($container) {
    $authUrl = $container->get('oauth_service')->getAuthUrl($provider);
    return new RedirectResponse($authUrl);
});

$router->get('/auth/{provider}/callback', function ($provider, Request $request) use ($container) {
    $userData = $container->get('oauth_service')->handleCallback(
        $provider, 
        $request->get('code')
    );
    
    $user = $container->get('user_service')->findOrCreateFromOAuth($userData);
    $container->get('auth')->login($user);
    
    return new RedirectResponse('/');
}); 