<?php
$router->group([
    'prefix' => '/mobile-api',
    'middleware' => 'mobile'
], function ($router) {
    $router->get('/posts', 'MobilePostController@index');
    $router->get('/posts/{id}', 'MobilePostController@show');
}); 