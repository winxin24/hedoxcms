<?php
class PostTest extends TestCase {
    public function test_create_post_as_admin() {
        $user = User::factory()->admin()->create();
        $this->actingAs($user);

        $response = $this->postJson('/api/posts', [
            'title' => 'Test Post',
            'content' => 'Sample content'
        ]);

        $response->assertStatus(201)
            ->assertJsonPath('title', 'Test Post');
    }

    public function test_guest_cannot_create_post() {
        $response = $this->postJson('/api/posts', [
            'title' => 'Test Post',
            'content' => 'Sample content'
        ]);

        $response->assertStatus(401);
    }
} 