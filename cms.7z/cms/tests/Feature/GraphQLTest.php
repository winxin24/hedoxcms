<?php
class GraphQLTest extends TestCase {
    public function test_post_query() {
        $post = Post::factory()->create();
        
        $query = '
            query ($id: ID!) {
                post(id: $id) {
                    id
                    title
                }
            }
        ';
        
        $response = $this->postJson('/graphql', [
            'query' => $query,
            'variables' => ['id' => $post->id]
        ]);
        
        $response->assertJson([
            'data' => [
                'post' => [
                    'id' => (string)$post->id,
                    'title' => $post->title
                ]
            ]
        ]);
    }
} 