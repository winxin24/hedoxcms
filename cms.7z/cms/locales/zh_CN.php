<?php
return [
    'Welcome' => '欢迎',
    'Page not found' => '页面未找到',
    'Search results for "{{query}}"' => '“{{query}}”的搜索结果'
]; 