<?php
class DevTools {
    public function generateApiDocs(): void {
        $routes = Route::getRoutes();
        $docs = [];
        
        foreach ($routes as $route) {
            $docs[$route->uri()] = [
                'methods' => $route->methods(),
                'action' => $route->getActionName(),
                'params' => $this->parseParameters($route)
            ];
        }
        
        file_put_contents(base_path('api-docs.json'), json_encode($docs));
    }

    public function mockResponse(string $endpoint, array $data): void {
        $this->container->bind($endpoint, fn() => new JsonResponse($data));
    }
} 