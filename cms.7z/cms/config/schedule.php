<?php
$scheduler->addJob('daily_backup', '0 3 * * *', function () {
    $backupService = $container->get('backup_service');
    $backupService->createBackup('daily');
});

$scheduler->addJob('clear_temp_files', '*/15 * * * *', function () {
    $fileService = $container->get('file_service');
    $fileService->cleanTempDirectory();
}); 