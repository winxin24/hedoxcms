-- 用户表增强
CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    uuid BINARY(16) NOT NULL UNIQUE,
    username VARCHAR(50) UNIQUE COLLATE utf8mb4_bin,
    email VARCHAR(100) UNIQUE,
    password_hash CHAR(97) NOT NULL, -- argon2id格式
    status ENUM('active','inactive','suspended') DEFAULT 'active',
    created_at DATETIME(6) DEFAULT CURRENT_TIMESTAMP(6),
    INDEX idx_users_status (status)
) ENGINE=InnoDB ROW_FORMAT=COMPRESSED;

-- 内容表分片设计
CREATE TABLE posts_01 (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    author_id INT UNSIGNED NOT NULL,
    title VARCHAR(200) NOT NULL,
    content MEDIUMTEXT,
    type ENUM('post','page') NOT NULL,
    status ENUM('draft','publish','trash') DEFAULT 'draft',
    comment_count INT UNSIGNED DEFAULT 0,
    created_at DATETIME(6) DEFAULT CURRENT_TIMESTAMP(6),
    FULLTEXT INDEX idx_content (title, content)
) PARTITION BY HASH(id) PARTITIONS 8; 