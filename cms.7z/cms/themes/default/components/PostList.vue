<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'

const props = defineProps({
    category: String,
    pageSize: {
        type: Number,
        default: 10
    }
})

const router = useRouter()
const posts = ref([])
const currentPage = ref(1)
const totalPages = ref(1)

onMounted(async () => {
    await loadPosts()
})

async function loadPosts(page = 1) {
    const response = await fetch(`/api/posts?category=${props.category}&page=${page}&size=${props.pageSize}`)
    const data = await response.json()
    posts.value = data.items
    totalPages.value = data.total_pages
    currentPage.value = data.current_page
}

function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString()
}
</script>

<template>
    <div class="post-list">
        <article v-for="post in posts" :key="post.id" class="post-card">
            <h2 @click="router.push(`/post/${post.slug}`)">{{ post.title }}</h2>
            <div class="meta">
                <span class="author">{{ post.author }}</span>
                <time class="date">{{ formatDate(post.created_at) }}</time>
            </div>
            <p class="excerpt">{{ post.excerpt }}</p>
        </article>
        <div class="pagination">
            <button 
                v-for="page in totalPages" 
                :key="page"
                :class="{ active: page === currentPage }"
                @click="loadPosts(page)"
            >
                {{ page }}
            </button>
        </div>
    </div>
</template> 