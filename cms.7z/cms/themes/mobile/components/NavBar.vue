<template>
    <nav class="mobile-nav">
        <button @click="toggleMenu" class="menu-btn">
            <i class="icon-menu"></i>
        </button>
        <transition name="slide">
            <div v-if="menuOpen" class="menu-panel">
                <router-link to="/">首页</router-link>
                <router-link to="/posts">文章</router-link>
            </div>
        </transition>
    </nav>
</template>

<script setup>
import { ref } from 'vue'

const menuOpen = ref(false)

function toggleMenu() {
    menuOpen.value = !menuOpen.value
}
</script> 