<?php
class CrossPlatformSync {
    public function syncContent(Content $content, array $platforms): void {
        foreach ($platforms as $platform) {
            $adapter = $this->getAdapter($platform);
            $transformed = $this->transformContent($content, $adapter::FORMAT);
            
            try {
                $adapter->publish($transformed);
                $this->logSyncStatus($content, $platform, true);
            } catch (SyncException $e) {
                $this->handleSyncError($content, $platform, $e);
            }
        }
    }

    private function transformContent(Content $content, string $format): array {
        return match($format) {
            'wordpress' => [
                'title' => $content->title,
                'content' => $content->body,
                'status' => 'publish'
            ],
            'medium' => [
                'title' => $content->title,
                'contentFormat' => 'html',
                'content' => $content->html_body
            ]
        };
    }
} 