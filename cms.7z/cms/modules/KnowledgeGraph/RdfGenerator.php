<?php
class RdfGenerator {
    private $graph;

    public function __construct() {
        $this->graph = new \EasyRdf\Graph();
    }

    public function generateFromPost(Post $post): void {
        $ns = [
            'dct' => 'http://purl.org/dc/terms/',
            'schema' => 'http://schema.org/'
        ];
        
        $resource = $this->graph->resource(
            url("/posts/{$post->id}"),
            'schema:BlogPosting'
        );
        
        $resource->add('dct:title', $post->title);
        $resource->add('dct:creator', $this->getAuthorResource($post->author));
        $resource->add('schema:datePublished', $post->created_at);
    }

    public function export(string $format = 'turtle'): string {
        return $this->graph->serialise($format);
    }

    private function getAuthorResource(User $user): \EasyRdf\Resource {
        $author = $this->graph->resource(
            url("/users/{$user->id}"), 
            'schema:Person'
        );
        $author->set('schema:name', $user->name);
        return $author;
    }
} 