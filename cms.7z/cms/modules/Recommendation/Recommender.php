<?php
class Recommender {
    public function recommendPosts(int $userId, int $limit = 5): array {
        $model = $this->loadModel('post_recommender');
        $userVector = $this->getUserVector($userId);
        
        return Post::query()
            ->selectRaw('*, DOT_PRODUCT(embedding, ?) as score', [$userVector])
            ->orderByDesc('score')
            ->limit($limit)
            ->get();
    }

    private function loadModel(string $name): object {
        return Model::where('name', $name)
            ->orderByDesc('version')
            ->firstOrFail()
            ->load();
    }
} 