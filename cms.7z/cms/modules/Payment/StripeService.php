<?php
class StripeService {
    const CURRENCY = 'usd';
    
    public function createPaymentIntent(float $amount, array $metadata = []): string {
        \Stripe\Stripe::setApiKey(env('STRIPE_SECRET'));
        
        $intent = \Stripe\PaymentIntent::create([
            'amount' => $this->convertToCents($amount),
            'currency' => self::CURRENCY,
            'metadata' => $metadata
        ]);
        
        return $intent->client_secret;
    }

    public function handleWebhook(Request $request): void {
        $event = \Stripe\Webhook::constructEvent(
            $request->getContent(),
            $request->header('Stripe-Signature'),
            env('STRIPE_WEBHOOK_SECRET')
        );

        switch ($event->type) {
            case 'payment_intent.succeeded':
                $this->handlePaymentSuccess($event->data->object);
                break;
        }
    }

    private function handlePaymentSuccess($paymentIntent) {
        $order = Order::find($paymentIntent->metadata->order_id);
        $order->update(['status' => 'paid']);
    }

    private function convertToCents(float $amount): int {
        return (int)($amount * 100);
    }
} 