<?php
class AuditService {
    public function generateReport(): array {
        return [
            'user_roles' => $this->checkRolePermissions(),
            'ssl' => $this->checkSsl(),
            'recent_logins' => $this->getRecentLogins(),
            'patch_status' => $this->checkSecurityPatches()
        ];
    }

    private function checkRolePermissions(): array {
        return DB::table('roles')
            ->select('name')
            ->whereRaw('JSON_LENGTH(permissions) = 0')
            ->get()
            ->toArray();
    }

    private function checkSsl(): array {
        return [
            'valid' => request()->secure(),
            'expires' => $this->getSslExpiryDate()
        ];
    }

    private function getRecentLogins(): array {
        return LoginLog::where('created_at', '>', now()->subDays(7))
            ->orderByDesc('created_at')
            ->limit(50)
            ->get()
            ->toArray();
    }
} 