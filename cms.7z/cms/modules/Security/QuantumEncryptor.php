<?php
class QuantumEncryptor {
    public function encrypt(string $data, string $key): string {
        $iv = random_bytes(12);
        $cipherText = openssl_encrypt(
            $data, 
            'aes-256-gcm',
            hash('sha3-512', $key, true),
            OPENSSL_RAW_DATA,
            $iv,
            $tag
        );
        
        return base64_encode($iv.$tag.$cipherText);
    }

    public function decrypt(string $encrypted, string $key): string {
        $data = base64_decode($encrypted);
        $iv = substr($data, 0, 12);
        $tag = substr($data, 12, 16);
        $cipherText = substr($data, 28);
        
        return openssl_decrypt(
            $cipherText,
            'aes-256-gcm',
            hash('sha3-512', $key, true),
            OPENSSL_RAW_DATA,
            $iv,
            $tag
        );
    }
} 