<?php
class MediaService {
    const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'application/pdf'];
    const MAX_SIZE = 10485760; // 10MB

    public function upload(UploadedFile $file): array {
        $this->validateFile($file);

        $hash = hash_file('sha256', $file->getPathname());
        $extension = $file->guessExtension();
        $filename = $hash . '.' . $extension;
        
        $file->move($this->getStoragePath(), $filename);

        return [
            'original_name' => $file->getClientOriginalName(),
            'mime_type' => $file->getMimeType(),
            'file_size' => $file->getSize(),
            'storage_path' => $filename,
            'url' => $this->generateUrl($filename)
        ];
    }

    private function validateFile(UploadedFile $file): void {
        if (!in_array($file->getMimeType(), self::ALLOWED_TYPES)) {
            throw new InvalidMediaTypeException();
        }

        if ($file->getSize() > self::MAX_SIZE) {
            throw new FileSizeExceededException();
        }
    }

    private function generateUrl(string $filename): string {
        return '/storage/' . ltrim($filename, '/');
    }
} 