<?php
class BackupService {
    const MAX_BACKUPS = 7;

    public function createBackup(string $type): string {
        $filename = $this->generateFilename($type);
        $this->dumpDatabase($filename);
        $this->rotateBackups();
        return $filename;
    }

    private function generateFilename(string $type): string {
        return sprintf(
            '%s_%s_%s.sql.gz',
            $type,
            date('Ymd-His'),
            substr(sha1(uniqid()), 0, 8)
        );
    }

    private function dumpDatabase(string $filename): void {
        $command = sprintf(
            'mysqldump -h%s -u%s -p%s %s | gzip > %s',
            escapeshellarg(DB_HOST),
            escapeshellarg(DB_USER),
            escapeshellarg(DB_PASS),
            escapeshellarg(DB_NAME),
            escapeshellarg(BACKUP_DIR.'/'.$filename)
        );
        exec($command, $output, $status);
        
        if ($status !== 0) {
            throw new BackupFailedException($command);
        }
    }

    private function rotateBackups(): void {
        $files = glob(BACKUP_DIR.'/*.sql.gz');
        if (count($files) > self::MAX_BACKUPS) {
            usort($files, function ($a, $b) {
                return filemtime($a) <=> filemtime($b);
            });
            array_map('unlink', array_slice($files, 0, -self::MAX_BACKUPS));
        }
    }
} 