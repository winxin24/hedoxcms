<?php
class CdnManager {
    public function purge(array $urls): void {
        $providers = config('cdn.providers');
        
        foreach ($providers as $provider) {
            $this->getClient($provider)->purge($urls);
        }
    }

    private function getClient(string $provider): CdnClient {
        return match($provider) {
            'cloudflare' => new CloudflareClient(
                config('cdn.cloudflare.zone'),
                config('cdn.cloudflare.key')
            ),
            'akamai' => new AkamaiClient(
                config('cdn.akamai.host'),
                config('cdn.akamai.client_token')
            )
        };
    }
} 