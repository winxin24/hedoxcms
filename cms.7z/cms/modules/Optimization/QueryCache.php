<?php
class QueryCache {
    public function remember(string $key, callable $callback, int $ttl = 3600) {
        $tags = $this->getQueryTags();
        return Cache::tags($tags)->remember($key, $ttl, $callback);
    }

    private function getQueryTags(): array {
        $backtrace = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5);
        return array_map(function ($trace) {
            return md5($trace['file'].$trace['line']);
        }, $backtrace);
    }
} 