<?php
class Transcoder {
    public function process(string $input, string $format): array {
        $output = tempnam(sys_get_temp_dir(), 'video');
        
        $command = sprintf(
            'ffmpeg -i %s -c:v libx264 -preset fast %s 2>&1',
            escapeshellarg($input),
            escapeshellarg("$output.$format")
        );
        
        exec($command, $output, $status);
        
        return [
            'path' => "$output.$format",
            'size' => filesize("$output.$format"),
            'duration' => $this->getDuration($input)
        ];
    }

    private function getDuration(string $file): float {
        // 使用ffprobe获取视频时长
    }
} 