<?php
class CommentController extends ApiController {
    public function listComments(Request $request) {
        $postId = $request->get('post_id');
        $status = $request->get('status', 'approved');
        
        $comments = $this->container->get('comment_service')
            ->getCommentsByPost($postId, $status);
            
        return $this->paginate($comments);
    }

    public function createComment(Request $request) {
        $data = $this->validateCommentData($request);
        $comment = $this->container->get('comment_service')->create($data);
        return $this->createdResponse($comment);
    }

    private function validateCommentData(Request $request): array {
        return $this->validate($request, [
            'post_id' => 'required|integer',
            'author' => 'required|max:100',
            'email' => 'required|email',
            'content' => 'required|max:1000',
            'parent_id' => 'nullable|integer'
        ]);
    }
} 