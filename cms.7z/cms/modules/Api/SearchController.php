<?php
class SearchController extends ApiController {
    public function search(Request $request) {
        $query = $request->get('q');
        $results = $this->container->get('search_service')->search($query);
        return $this->successResponse($results);
    }

    public function reindex(Request $request) {
        $postService = $this->container->get('post_service');
        $searchService = $this->container->get('search_service');
        
        $posts = $postService->getAllPosts();
        foreach ($posts as $post) {
            $searchService->indexPost($post);
        }
        
        return $this->successResponse(['indexed' => count($posts)]);
    }
} 