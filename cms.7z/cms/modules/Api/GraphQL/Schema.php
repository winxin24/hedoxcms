<?php
use GraphQL\Type\Definition\Type;
use GraphQL\Type\Definition\ObjectType;

$postType = new ObjectType([
    'name' => 'Post',
    'fields' => [
        'id' => Type::nonNull(Type::id()),
        'title' => Type::nonNull(Type::string()),
        'content' => Type::nonNull(Type::string()),
        'author' => [
            'type' => Type::nonNull($userType),
            'resolve' => function ($post) {
                return User::find($post['author_id']);
            }
        ]
    ]
]);

$queryType = new ObjectType([
    'name' => 'Query',
    'fields' => [
        'post' => [
            'type' => $postType,
            'args' => [
                'id' => Type::nonNull(Type::id())
            ],
            'resolve' => function ($root, $args) {
                return Post::find($args['id']);
            }
        ]
    ]
]);

$schema = new \GraphQL\Type\Schema([
    'query' => $queryType
]); 