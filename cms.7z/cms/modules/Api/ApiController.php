<?php
class ApiController {
    const VERSION = '1.0';

    public function listPosts(Request $request) {
        $query = new PostQuery();
        return $this->paginate(
            $query->getRecentPosts(),
            $request->get('page', 1)
        );
    }

    public function createPost(Request $request) {
        $data = $this->validatePostData($request);
        $post = $this->container->get('post_service')->create($data);
        return $this->createdResponse($post);
    }

    private function validatePostData(Request $request): array {
        $validator = new Validator($request->all(), [
            'title' => 'required|max:200',
            'content' => 'required',
            'status' => 'in:draft,publish'
        ]);

        if (!$validator->validate()) {
            throw new InvalidRequestException($validator->errors());
        }

        return $validator->validated();
    }

    private function paginate(array $items, int $page) {
        // 分页逻辑实现
    }
} 