<?php
class GraphQLController {
    public function handle(Request $request) {
        $schema = $this->container->get('graphql_schema');
        $input = json_decode($request->getContent(), true);
        
        $result = GraphQL::executeQuery(
            $schema,
            $input['query'],
            null,
            null,
            $input['variables'] ?? []
        );
        
        return response()->json($result->toArray());
    }
} 