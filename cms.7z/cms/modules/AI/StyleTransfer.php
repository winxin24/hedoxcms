<?php
class StyleTransfer {
    public function transfer(string $content, string $style): string {
        $output = tempnam(sys_get_temp_dir(), 'styled');
        
        $this->executePythonScript(
            base_path('ai_models/style_transfer.py'),
            [
                '--content' => $content,
                '--style' => $style,
                '--output' => $output
            ]
        );
        
        return $this->postProcessImage($output);
    }

    private function executePythonScript(string $script, array $args): void {
        $command = escapeshellcmd("python3 {$script} ") 
                 . implode(' ', array_map(
                     fn ($k, $v) => escapeshellarg("$k=$v"),
                     array_keys($args), $args
                   ));
        
        exec($command, $output, $status);
        if ($status !== 0) {
            throw new StyleTransferException(implode("\n", $output));
        }
    }
} 