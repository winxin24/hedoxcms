<?php
class NodeManager {
    public function registerNode(array $nodeData): Node {
        return DB::transaction(function () use ($nodeData) {
            $node = Node::updateOrCreate(
                ['ip' => $nodeData['ip']],
                $nodeData
            );
            
            $this->syncEdgeModules($node);
            return $node;
        });
    }

    private function syncEdgeModules(Node $node): void {
        $required = config('edge.modules');
        $existing = $node->modules->pluck('name');
        
        $this->installMissingModules($node, $required->diff($existing));
        $this->removeDeprecatedModules($node, $existing->diff($required));
    }

    public function dispatchEdgeTask(Node $node, string $task): void {
        MQTT::publish("nodes/{$node->id}/tasks", [
            'task' => $task,
            'payload' => $this->prepareTaskPayload($task)
        ]);
    }
} 