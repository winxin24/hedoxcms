<?php
class RoleManager {
    const ROLES = [
        'administrator' => [
            'manage_options',
            'edit_users',
            'manage_content'
        ],
        'editor' => [
            'edit_posts',
            'upload_files',
            'moderate_comments'
        ],
        'author' => [
            'edit_posts',
            'delete_posts',
            'upload_files'
        ],
        'subscriber' => [
            'read'
        ]
    ];

    public function userCan(int $userId, string $capability): bool {
        $user = $this->getUserWithRoles($userId);
        return array_intersect($this->getRoleCapabilities($user['roles']), [$capability]);
    }

    private function getUserWithRoles(int $userId): array {
        // 获取用户及其角色信息
    }

    private function getRoleCapabilities(array $roles): array {
        $capabilities = [];
        foreach ($roles as $role) {
            if (isset(self::ROLES[$role])) {
                $capabilities = array_merge($capabilities, self::ROLES[$role]);
            }
        }
        return array_unique($capabilities);
    }
} 