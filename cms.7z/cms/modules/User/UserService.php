<?php

class UserService {
    private $db;
    private $cache;
    
    public function __construct(PDO $db, Redis $cache) {
        $this->db = $db;
        $this->cache = $cache;
    }
    
    public function createUser(array $data) {
        $stmt = $this->db->prepare("INSERT INTO users (...) VALUES (...)");
        // 使用预处理语句防止SQL注入
    }
    
    public function getUserWithCache(int $id) {
        $cacheKey = "user_{$id}";
        if ($data = $this->cache->get($cacheKey)) {
            return json_decode($data, true);
        }
        // 数据库查询并缓存
    }

    public function findOrCreateFromOAuth(array $data): User {
        $user = $this->findByOAuthId($data['id']);
        if ($user) {
            return $user;
        }

        $user = $this->findByEmail($data['email']);
        if ($user) {
            $this->linkOAuthAccount($user, $data);
            return $user;
        }

        return $this->createUser([
            'username' => $this->generateUniqueUsername($data['name']),
            'email' => $data['email'],
            'oauth_id' => $data['id'],
            'avatar' => $data['picture'] ?? null
        ]);
    }

    private function generateUniqueUsername(string $name): string {
        $base = preg_replace('/[^a-z0-9]/i', '', strtolower($name));
        $username = $base;
        $counter = 1;
        
        while ($this->usernameExists($username)) {
            $username = $base . $counter++;
        }
        
        return $username;
    }
} 