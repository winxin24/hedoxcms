<?php
class SchedulerService {
    public function distributeTask(string $taskClass, array $payload): void {
        $node = $this->selectWorkerNode();
        
        Redis::connection('task')->publish($node->queue, json_encode([
            'task' => $taskClass,
            'data' => $payload,
            'attempts' => 0
        ]));
    }

    private function selectWorkerNode(): object {
        return DB::table('worker_nodes')
            ->where('status', 'active')
            ->orderBy('load')
            ->first();
    }

    public function failoverHandler(Node $failedNode): void {
        DB::transaction(function () use ($failedNode) {
            $tasks = Task::where('node_id', $failedNode->id)
                ->where('status', 'processing')
                ->get();
            
            foreach ($tasks as $task) {
                $this->redispatchTask($task);
            }
            
            $failedNode->update(['status' => 'down']);
        });
    }
} 