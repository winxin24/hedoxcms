<?php
class CommentService {
    const STATUSES = ['approved', 'pending', 'spam', 'trash'];
    
    public function createComment(array $data): array {
        $this->validateCommentData($data);
        
        return DB::transaction(function () use ($data) {
            $commentId = $this->insertComment($data);
            $this->updatePostCommentCount($data['post_id']);
            return $this->getComment($commentId);
        });
    }

    private function validateCommentData(array $data): void {
        Validator::validate($data, [
            'post_id' => 'required|exists:posts,id',
            'author' => 'required|max:100',
            'email' => 'required|email',
            'content' => 'required|max:1000',
            'parent_id' => 'nullable|exists:comments,id'
        ]);
    }

    private function insertComment(array $data): int {
        $stmt = DB::prepare("INSERT INTO comments (...) VALUES (...)");
        // 使用预处理语句
    }

    private function updatePostCommentCount(int $postId): void {
        DB::statement(
            "UPDATE posts SET comment_count = comment_count + 1 WHERE id = ?",
            [$postId]
        );
    }
} 