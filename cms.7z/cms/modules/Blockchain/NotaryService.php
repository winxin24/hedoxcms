<?php
class NotaryService {
    public function notarize(string $content): string {
        $hash = hash('sha256', $content);
        $tx = [
            'from' => config('blockchain.wallet'),
            'to' => '0xNotaryContract',
            'value' => '0',
            'data' => '0x' . bin2hex($hash)
        ];

        $signed = $this->signTransaction($tx);
        return $this->sendTransaction($signed);
    }

    private function signTransaction(array $tx): string {
        $privateKey = config('blockchain.private_key');
        return Ethereum::sign($tx, $privateKey);
    }
} 