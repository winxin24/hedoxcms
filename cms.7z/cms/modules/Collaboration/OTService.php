<?php
class OTService {
    public function applyOperation(string $document, array $operation): string {
        $doc = json_decode($document, true);
        $path = implode('.', $operation['path']);
        
        data_set($doc, $path, $operation['value']);
        return json_encode($doc);
    }

    public function transformOperations(array $op1, array $op2): array {
        // 实现操作转换算法
        if ($op1['path'] == $op2['path']) {
            return [$this->transformConflict($op1, $op2)];
        }
        return [$op1, $op2];
    }

    private function transformConflict(array $op1, array $op2): array {
        return $op1['timestamp'] > $op2['timestamp'] ? $op1 : $op2;
    }
} 