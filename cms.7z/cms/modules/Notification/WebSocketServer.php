<?php
class WebSocketServer implements MessageComponentInterface {
    private $clients;
    private $auth;

    public function __construct(AuthService $auth) {
        $this->clients = new \SplObjectStorage;
        $this->auth = $auth;
    }

    public function onOpen(ConnectionInterface $conn) {
        $query = $conn->httpRequest->getUri()->getQuery();
        parse_str($query, $params);
        
        try {
            $user = $this->auth->validateToken($params['token']);
            $conn->user_id = $user['id'];
            $this->clients->attach($conn);
        } catch (AuthException $e) {
            $conn->close();
        }
    }

    public function onMessage(ConnectionInterface $from, $msg) {
        $data = json_decode($msg, true);
        $this->handleCommand($from, $data);
    }

    private function handleCommand(ConnectionInterface $conn, array $data) {
        switch ($data['type']) {
            case 'subscribe':
                $conn->channels = $data['channels'];
                break;
            case 'unsubscribe':
                $conn->channels = array_diff($conn->channels, $data['channels']);
                break;
        }
    }

    public function sendToUser(int $userId, array $message) {
        foreach ($this->clients as $client) {
            if ($client->user_id === $userId) {
                $client->send(json_encode($message));
            }
        }
    }

    public function onClose(ConnectionInterface $conn) {
        $this->clients->detach($conn);
    }

    public function onError(ConnectionInterface $conn, \Exception $e) {
        $conn->close();
    }
} 