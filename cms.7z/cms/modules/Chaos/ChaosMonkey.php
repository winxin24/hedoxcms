<?php
class ChaosMonkey {
    public function injectFailure(): void {
        if ($this->shouldInject()) {
            $this->triggerRandomFailure();
        }
    }

    private function shouldInject(): bool {
        return rand(1, 100) <= config('chaos.failure_rate');
    }

    private function triggerRandomFailure(): void {
        $scenarios = [
            'database' => fn() => $this->disruptDatabase(),
            'network' => fn() => $this->simulateNetworkLatency(),
            'service' => fn() => $this->terminateRandomService()
        ];
        
        $scenario = array_rand($scenarios);
        $scenarios[$scenario]();
    }

    private function disruptDatabase(): void {
        match(rand(1, 3)) {
            1 => DB::connection()->disconnect(),
            2 => Cache::flush(),
            3 => DB::statement('SLEEP(5)')
        };
    }
} 