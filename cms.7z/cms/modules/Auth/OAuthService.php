<?php
class OAuthService {
    private $providers = [];
    
    public function registerProvider(string $name, array $config): void {
        $this->providers[$name] = new Provider\GenericProvider([
            'clientId'     => $config['client_id'],
            'clientSecret' => $config['client_secret'],
            'redirectUri'  => $config['redirect_uri'],
            'urlAuthorize' => $config['authorize_url'],
            'urlAccessToken' => $config['token_url'],
            'urlResourceOwnerDetails' => $config['userinfo_url']
        ]);
    }

    public function getAuthUrl(string $provider): string {
        return $this->getProvider($provider)->getAuthorizationUrl();
    }

    public function handleCallback(string $provider, string $code): array {
        $provider = $this->getProvider($provider);
        $token = $provider->getAccessToken('authorization_code', [
            'code' => $code
        ]);
        return $provider->getResourceOwner($token)->toArray();
    }

    private function getProvider(string $name): Provider\AbstractProvider {
        if (!isset($this->providers[$name])) {
            throw new ProviderNotRegisteredException($name);
        }
        return $this->providers[$name];
    }
} 