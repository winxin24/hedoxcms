<?php
class SiteManager {
    public function resolveSite(Request $request): Site {
        $domain = $request->getHost();
        return Cache::rememberForever("site_{$domain}", function () use ($domain) {
            return Site::where('domain', $domain)
                ->orWhere('aliases', 'like', "%\"{$domain}\"%")
                ->firstOrFail();
        });
    }

    public function switchTheme(Site $site): void {
        config()->set('theme.current', $site->theme);
    }

    public function sharedContent(string $type): Collection {
        return DB::table('shared_content')
            ->where('type', $type)
            ->where(function ($query) {
                $query->whereNull('sites')
                    ->orWhereJsonContains('sites', config('site.id'));
            })
            ->get();
    }
} 