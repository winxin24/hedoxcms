<?php
class SearchService {
    private $client;
    private $index;

    public function __construct(Client $client, string $index) {
        $this->client = $client;
        $this->index = $index;
    }

    public function indexPost(array $post): void {
        $params = [
            'index' => $this->index,
            'id'    => $post['id'],
            'body'  => $this->formatPost($post)
        ];
        $this->client->index($params);
    }

    public function search(string $query, int $size = 10): array {
        $params = [
            'index' => $this->index,
            'body'  => [
                'query' => [
                    'multi_match' => [
                        'query'  => $query,
                        'fields' => ['title^3', 'content', 'excerpt']
                    ]
                ],
                'size' => $size
            ]
        ];
        $response = $this->client->search($params);
        return $this->parseResults($response);
    }

    private function formatPost(array $post): array {
        return [
            'id' => $post['id'],
            'title' => $post['title'],
            'content' => strip_tags($post['content']),
            'excerpt' => $post['excerpt'],
            'author' => $post['author_name'],
            'created_at' => $post['created_at']
        ];
    }

    private function parseResults(array $response): array {
        return array_map(function ($hit) {
            return [
                'id' => $hit['_id'],
                'score' => $hit['_score'],
                'source' => $hit['_source']
            ];
        }, $response['hits']['hits']);
    }
} 