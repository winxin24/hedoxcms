<?php
class DecentralizedStorage {
    public function storeFile(string $path): array {
        $providers = config('decentralized.providers');
        $results = [];
        
        foreach ($providers as $provider) {
            $client = $this->getClient($provider);
            $results[$provider] = $client->upload($path);
        }
        
        return $results;
    }

    public function retrieveFile(string $cid): string {
        foreach (config('decentralized.providers') as $provider) {
            try {
                return $this->getClient($provider)->download($cid);
            } catch (StorageException $e) {
                continue;
            }
        }
        throw new FileNotFoundException($cid);
    }

    private function getClient(string $provider): StorageClient {
        return match($provider) {
            'ipfs' => new IPFSClient(config('decentralized.ipfs.gateway')),
            'swarm' => new SwarmClient(config('decentralized.swarm.bee_url'))
        };
    }
} 