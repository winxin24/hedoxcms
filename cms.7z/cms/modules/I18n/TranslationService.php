<?php
class TranslationService {
    private $loadedLocales = [];
    private $currentLocale = 'en_US';

    public function setLocale(string $locale): void {
        $this->currentLocale = $locale;
        if (!isset($this->loadedLocales[$locale])) {
            $this->loadLocale($locale);
        }
    }

    public function translate(string $text, array $params = []): string {
        $translation = $this->loadedLocales[$this->currentLocale][$text] ?? $text;
        return $this->replacePlaceholders($translation, $params);
    }

    private function loadLocale(string $locale): void {
        $path = LOCALE_PATH . "/{$locale}.php";
        if (!file_exists($path)) {
            throw new LocaleNotFoundException($locale);
        }
        $this->loadedLocales[$locale] = require $path;
    }

    private function replacePlaceholders(string $text, array $params): string {
        return preg_replace_callback('/\{\{(\w+)\}\}/', function ($matches) use ($params) {
            return $params[$matches[1]] ?? $matches[0];
        }, $text);
    }
} 