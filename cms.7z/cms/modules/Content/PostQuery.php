class PostQuery {
    public function getRecentPosts(int $limit = 10) {
        $sql = <<<SQL
        SELECT /*+ MAX_EXECUTION_TIME(1000) */
            p.id, p.title, p.excerpt, 
            u.username as author,
            COUNT(c.id) as comment_count
        FROM posts p
        FORCE INDEX (idx_posts_status_date)
        JOIN users u ON p.author_id = u.id
        LEFT JOIN comments c ON p.id = c.post_id
        WHERE p.status = 'publish'
        GROUP BY p.id
        ORDER BY p.created_at DESC
        LIMIT :limit
        SQL;
        
        // 使用预处理语句
    }
} 