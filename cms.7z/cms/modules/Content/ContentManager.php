class ContentManager {
    const POST_TYPES = ['post', 'page', 'attachment'];
    
    public function createPost(string $type, array $data) {
        if (!in_array($type, self::POST_TYPES)) {
            throw new InvalidArgumentException("Invalid post type");
        }
        
        $meta = [
            'created_at' => new DateTime(),
            'modified_at' => new DateTime(),
            'status' => 'draft'
        ];
        
        return $this->saveContent($type, array_merge($data, $meta));
    }
    
    private function saveContent(string $type, array $data) {
        // 分离内容主体和元数据存储
    }
} 