<?php
class ExperimentManager {
    public function assignVariant(string $experiment, int $userId): string {
        $hash = crc32($experiment . $userId);
        return ($hash % 100) < $this->getExperimentConfig($experiment)['split'] 
            ? 'variant_a' 
            : 'variant_b';
    }

    public function trackConversion(string $experiment, int $userId): void {
        DB::transaction(function () use ($experiment, $userId) {
            $variant = $this->getUserVariant($experiment, $userId);
            DB::table('ab_metrics')
                ->where('experiment', $experiment)
                ->where('variant', $variant)
                ->increment('conversions');
        });
    }

    private function getExperimentConfig(string $name): array {
        return config("ab_tests.{$name}", [
            'split' => 50,
            'metrics' => ['conversion_rate']
        ]);
    }
} 