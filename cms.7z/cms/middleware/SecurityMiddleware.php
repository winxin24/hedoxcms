<?php
class SecurityMiddleware {
    const RATE_LIMITS = [
        'api' => ['limit' => 100, 'window' => 60], // 60秒100次
        'login' => ['limit' => 5, 'window' => 300]
    ];

    public function handle(Request $request, Closure $next) {
        $this->sanitizeInput($request);
        
        if ($request->isMethod('POST')) {
            $this->validateCsrfToken($request);
        }

        $this->applyRateLimiting($request);

        $response = $next($request);

        // 响应头安全设置
        $response->headers->set('X-Content-Type-Options', 'nosniff');
        $response->headers->set('X-Frame-Options', 'DENY');
        $response->headers->set('Content-Security-Policy', "default-src 'self'");

        return $response;
    }

    private function sanitizeInput(Request $request): void {
        $inputs = $request->all();
        array_walk_recursive($inputs, function (&$value) {
            $value = htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
        });
        $request->replace($inputs);
    }

    private function validateCsrfToken(Request $request): void {
        $token = $request->headers->get('X-CSRF-TOKEN') 
               ?: $request->input('_token');
        
        if (!hash_equals($_SESSION['csrf_token'], $token)) {
            throw new InvalidCsrfTokenException();
        }
    }

    private function applyRateLimiting(Request $request): void {
        $clientKey = $request->getClientIp();
        foreach (self::RATE_LIMITS as $type => $config) {
            $key = "rate_limit:{$type}:{$clientKey}";
            $current = $this->redis->incr($key);
            if ($current > $config['limit']) {
                throw new RateLimitExceededException();
            }
            if ($current === 1) {
                $this->redis->expire($key, $config['window']);
            }
        }
    }
} 