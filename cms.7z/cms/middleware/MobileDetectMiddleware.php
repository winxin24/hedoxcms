<?php
class MobileDetectMiddleware {
    public function handle(Request $request, Closure $next) {
        $detect = new Mobile_Detect();
        
        if ($detect->isMobile()) {
            $request->attributes->set('theme', 'mobile');
        } else {
            $request->attributes->set('theme', 'desktop');
        }

        return $next($request);
    }
} 